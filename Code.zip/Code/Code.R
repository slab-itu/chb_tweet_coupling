install.packages("dplyr")
install.packages("Matrix")
install.packages("stringr")
install.packages("igraph")
install.packages("bibliometrix")
install.packages("caret")
install.packages("e1071")

install.packages("igraph")
install.packages("network") 
install.packages("sna")
install.packages("ndtv")
install.packages('splitstackshape')
install.packages('dbscan')1
install.packages('RSSL')
install.packages("lsa")
install.packages("BiRewire")

library("dplyr")
library("Matrix")
library("stringr")
library("igraph")
library("bibliometrix")
library("caret")
library("e1071")

library("igraph")
library("network") 
library("sna")
library("ndtv")
library("RColorBrewer")
library("splitstackshape")
library("plyr")
library("dbscan")
library("RSSL")
library("lsa")
library("SnowballC")
library("BiRewire")


scopusFile<-read.csv("scopus.csv",stringsAsFactors = FALSE)

refrencesListForParsing <- strsplit(scopusFile$Title.Source.title.DOI.Link.References.EID, "\t")

scopusDataFrame <- data.frame(
                 DOI=character(),
                 Refrences=character(),
                 stringsAsFactors = FALSE)

for(i in 1:length(refrencesListForParsing))
{
    refrence <- data.frame(
    DOI=refrencesListForParsing[[i]][3],
    Refrences=refrencesListForParsing[[i]][5],
    stringsAsFactors = FALSE)
    
    scopusDataFrame <-rbind(scopusDataFrame,refrence) 
}

write.csv(scopusDataFrame, file = "DoiWithRefrences.csv", row.names = FALSE)

library("stringr") 

#Split Refrences on ';'
splittedRefrences <- strsplit(scopusDataFrame$Refrences, split = ";")

OneToOneCorespondeseBetweenDOIAndRef<-data.frame(DOI = rep(scopusDataFrame$DOI, sapply(splittedRefrences, length)),References = unlist(splittedRefrences), stringsAsFactors = FALSE)
for (i in 1: nrow(OneToOneCorespondeseBetweenDOIAndRef))
{ 
  #Split each refrence on , and then choose longest string
  exampleSplited <-  strsplit( OneToOneCorespondeseBetweenDOIAndRef[i,]$References, split = ",") 
  OneToOneCorespondeseBetweenDOIAndRef[i,]$References<- exampleSplited[[1]][nchar(exampleSplited[[1]])==max(nchar(exampleSplited[[1]]))][1]
}

#Removed Empty Refrences
OneToOneCorespondeseBetweenDOIAndRef<- OneToOneCorespondeseBetweenDOIAndRef[which(OneToOneCorespondeseBetweenDOIAndRef$References != ""),]
write.csv(OneToOneCorespondeseBetweenDOIAndRef, file = "OneToOneCorespondeseBetweenDOIAndRef.csv", row.names = FALSE)


#Create Matrix of Size Doi unique and unique Refrences
FinalDataRefrencesMatrix <- matrix(data = 0, nrow = length(unique(OneToOneCorespondeseBetweenDOIAndRef$DOI)), ncol = length(unique(OneToOneCorespondeseBetweenDOIAndRef$References)))

#Write row and column names
dimnames(FinalDataRefrencesMatrix) = list( unique(OneToOneCorespondeseBetweenDOIAndRef$DOI), unique(OneToOneCorespondeseBetweenDOIAndRef$References)) # column names

# Assign value to each with one whose refrences exist
for (i in 1: nrow(OneToOneCorespondeseBetweenDOIAndRef))
{
  FinalDataRefrencesMatrix[OneToOneCorespondeseBetweenDOIAndRef[i,]$DOI,OneToOneCorespondeseBetweenDOIAndRef[i,]$References] <- 1
}

write.csv(FinalDataRefrencesMatrix, file = "FinalDataRefrencesMatrix.csv", row.names = TRUE)

selectedReferencesColSumGreaterThanOne<-FinalDataRefrencesMatrix[,colSums(FinalDataRefrencesMatrix) >1]
selectedReferencesColSumGreaterThanOne <- selectedReferencesColSumGreaterThanOne[rowSums(selectedReferencesColSumGreaterThanOne)>0,]


FinalDataRefrencesSquareMatrix <- selectedReferencesColSumGreaterThanOne %*% t(selectedReferencesColSumGreaterThanOne)

sum(FinalDataRefrencesSquareMatrix[row(FinalDataRefrencesSquareMatrix) == col(FinalDataRefrencesSquareMatrix)] ==0)
count = 0
for(i in 1: nrow(FinalDataRefrencesSquareMatrix)){
  if (FinalDataRefrencesSquareMatrix[i,i] == 0) {
    count = count+1
    
  }
}

upperLimit <- nrow(FinalDataRefrencesSquareMatrix)-count
for(i in 1:upperLimit ){
  if (FinalDataRefrencesSquareMatrix[i,i] == 0) {
    FinalDataRefrencesSquareMatrix <- FinalDataRefrencesSquareMatrix[-i,-i]
  }
}

write.csv(FinalDataRefrencesSquareMatrix, file = "FinalDataRefrencesSquareMatrix.csv", row.names = FALSE)

write.csv(colSums(FinalDataRefrencesMatrix), file = "RefrencesCount.csv", row.names = FALSE)
write.csv(colSums(selectedReferencesColSumGreaterThanOne), file = "RefrencesCountGreaterThanOne.csv", row.names = FALSE)


plot(colSums(FinalDataRefrencesMatrix), col = rgb(red = 255, green = 90, blue = 0, maxColorValue = 255),  main= "Paper Refrences Count", xlab = "Number Of Rrefrences", ylab="Refrences Occurance Count")
plot(colSums(selectedReferencesColSumGreaterThanOne), col = rgb(red = 255, green = 90, blue = 0, maxColorValue = 255), main= "Refrenaces exist in more than one Paper", xlab = "Number Of Rrefrences", ylab="Refrences Occurance Count")


FinalDataRefrencesMatrix
FinalDataRefrencesSquareBinaryMatrix<- FinalDataRefrencesSquareMatrix 
FinalDataRefrencesSquareBinaryMatrix[FinalDataRefrencesSquareBinaryMatrix>1]<-1

finalDoi<- unique(OneToOneCorespondeseBetweenDOIAndRef$DOI)
demoDoi <- rownames(refrenceMatrix)
write.csv(scopusDataFrame, file = "DoiWithRefrences.csv", row.names = FALSE)


##########Tweet################

tweetFileWithDoi<-read.csv("all_tweets.csv",stringsAsFactors = FALSE)


tweetFileWithDoi<- tweetFileWithDoi[which(tweetFileWithDoi$doi != ""),]


#Create Matrix of Size Doi unique and unique Refrences
FinalDataTweetMatrix <- matrix(data = 0, nrow = length(unique(tweetFileWithDoi$doi)), ncol = length(unique(tweetFileWithDoi$screen_name)))

#Write row and column names
dimnames(FinalDataTweetMatrix) = list( unique(tweetFileWithDoi$doi), unique(tweetFileWithDoi$screen_name)) # column names

# Assign value to each with one whose tweet exist
for (i in 1: length(tweetFileWithDoi$doi))
{
  FinalDataTweetMatrix[tweetFileWithDoi[i,]$doi,tweetFileWithDoi[i,]$screen_name] <- 1
}

write.csv(FinalDataTweetMatrix, file = "FinalDataTweetMatrix.csv", row.names = TRUE)


selectedTweetColSumGreaterThanOne<-FinalDataTweetMatrix[,colSums(FinalDataTweetMatrix) > 1]
#selectedTweetColSumGreaterThanOne<-FinalDataTweetMatrix[rowSums(selectedTweetColSumGreaterThanOne)>0,]
sum(rowSums(selectedTweetColSumGreaterThanOne)==0)
FinalDataTweetSquareMatrix <- selectedTweetColSumGreaterThanOne %*% t(selectedTweetColSumGreaterThanOne)

FinalDataTweetSquareMatrix <- FinalDataTweetMatrix %*% t(FinalDataTweetMatrix)


plot(graph_from_adjacency_matrix(FinalDataTweetSquareMatrix,mode = c("undirected"), weighted = NULL, diag = FALSE),vertex.size=2,vertex.color="red",edge.color= "black", vertex.label=NA)
count = 0

for(i in 1: nrow(FinalDataTweetSquareMatrix)){
  if (FinalDataTweetSquareMatrix[i,i] == 0) {
    count = count+1
  }
}

upperLimit <- nrow(FinalDataTweetSquareMatrix)-count
for(i in 1:upperLimit ){
  if (FinalDataTweetSquareMatrix[i,i] == 0) {
    FinalDataTweetSquareMatrix <- FinalDataTweetSquareMatrix[-i,-i]
  }
}

write.csv(colSums(FinalDataTweetMatrix), file = "TweetCount.csv", row.names = FALSE)
write.csv(colSums(selectedTweetColSumGreaterThanOne), file = "TweetCountGreaterThanOne.csv", row.names = FALSE)

plot(colSums(FinalDataTweetMatrix), col = rgb(red = 255, green = 90, blue = 0, maxColorValue = 255),  main= "Paper Tweet Count", xlab = "Number of Tweeter", ylab="Tweeter Occurance Count")
plot(colSums(selectedTweetColSumGreaterThanOne), col = rgb(red = 255, green = 90, blue = 0, maxColorValue = 255), main= "Tweeter tweet in more than one Paper", xlab = "Number Of Tweeter", ylab="Tweeter Occurance Count")

heatmap(FinalDataTweetSquareMatrix, Rowv=NA, Colv=NA, col = heat.colors(256), scale="column", margins=c(5,10))

write.csv(FinalDataTweetSquareMatrix, file = "FinalDataTweetSquareMatrix.csv", row.names = FALSE)

###############################################

FinalDataTweetSquareBinaryMatrix

FinalDataRefrencesSquareBinaryMatrix
sampleRefreences <- matrix(data = 0, nrow = 100, ncol = 100)
dimnames(FinalDataRefrencesMatrix) = list( unique(OneToOneCorespondeseBetweenDOIAndRef$DOI), unique(OneToOneCorespondeseBetweenDOIAndRef$References))

k = 0 
l = 0 
for(i in 1: nrow(tempFinalDataRefrencesSquareBinaryMatrix)) {
  if (tempFinalDataRefrencesSquareBinaryMatrix[i,j] == 0 ){
   
      if( k <= 50)
      {
        sampleRefreences[i,j] = 0;
        k <- k+1
      }
      
  }else {
 
    if( L <= 50)
    {
     sampleRefreences[i,j] = 1
     dimnames(sampleRefreences[i,j]) = 
     l<-l+1
    }
  }
}

count = 0

for(i in 1: nrow(FinalDataRefrencesSquareMatrix)){
  if (FinalDataRefrencesSquareMatrix[i,i] == 0) {
    count = count + 1
  }
}

for(i in 1: nrow(FinalDataRefrencesSquareMatrix)){
  if (FinalDataRefrencesSquareMatrix[i,i] == 0) {
    count = count + 1
  }
}


upperLimit <- nrow(FinalDataRefrencesSquareBinaryMatrix)-count
for(i in 1: upperLimit){
  if (FinalDataRefrencesSquareBinaryMatrix[i,i] == 0) {
    #count = count + 1
    FinalDataRefrencesSquareBinaryMatrix <- FinalDataRefrencesSquareBinaryMatrix[-i,-i]
  }
}
count = 0
for(i in 1: nrow(FinalDataTweetSquareBinaryMatrix)){
  if (FinalDataTweetSquareBinaryMatrix[i,i] == 0) {
    #count = count+1
    FinalDataTweetSquareBinaryMatrix <- FinalDataTweetSquareBinaryMatrix[-i,-i]
  }
}


##### Comparison  between Bibliographic coupling and tweet coupling ##################


FinalDataTweetSquareBinaryMatrix <- FinalDataTweetSquareMatrix 
FinalDataTweetSquareBinaryMatrix[FinalDataTweetSquareBinaryMatrix>1] <- 1

FinalDataRefrencesSquareBinaryMatrix <- FinalDataRefrencesSquareBinaryMatrix[intersect(rownames(FinalDataRefrencesSquareBinaryMatrix), rownames(FinalDataTweetSquareBinaryMatrix)),intersect(colnames(FinalDataRefrencesSquareBinaryMatrix), colnames(FinalDataTweetSquareBinaryMatrix))]
FinalDataTweetSquareBinaryMatrix     <- FinalDataTweetSquareBinaryMatrix[intersect(rownames(FinalDataRefrencesSquareBinaryMatrix), rownames(FinalDataTweetSquareBinaryMatrix)),intersect(colnames(FinalDataRefrencesSquareBinaryMatrix), colnames(FinalDataTweetSquareBinaryMatrix))]
#### Choose sample from tweeter square binary matrix
nba_matrix <- FinalDataTweetSquareBinaryMatrix[1:50,1:50]
#### Make all the elment in main diagonal 0
diag(nba_matrix) = 0
####Heat map
nba_heatmap <- heatmap(nba_matrix, Rowv=NA, Colv=NA, col = brewer.pal(9, "Blues"), scale="column", margins=c(5,10))

write.csv(FinalDataTweetSquareMatrix, file = "VosViewerData/FinalDataTweetSquareMatrix.csv", col.names = FALSE)
write.csv(FinalDataRefrencesSquareMatrix, file = "VosViewerData/FinalDataRefrencesSquareMatrix.csv", col.names = FALSE)




tempFinalDataRefrencesSquareBinaryMatrix<-FinalDataRefrencesSquareBinaryMatrix
tempFinalDataTweetSquareBinaryMatrix<-FinalDataTweetSquareBinaryMatrix

for(i in 1: nrow(tempFinalDataRefrencesSquareBinaryMatrix)){
  tempFinalDataRefrencesSquareBinaryMatrix[i,i] <- 0
}

for(i in 1: nrow(tempFinalDataTweetSquareBinaryMatrix)){
  tempFinalDataTweetSquareBinaryMatrix[i,i] <- 0
}


for(i in 1: nrow(tempFinalDataRefrencesSquareBinaryMatrix)){
   for(j in 1: nrow(tempFinalDataRefrencesSquareBinaryMatrix)){
    if (tempFinalDataRefrencesSquareBinaryMatrix[j,i]==1) {
      tempFinalDataRefrencesSquareBinaryMatrix[j,which(tempFinalDataRefrencesSquareBinaryMatrix[i,]==1)]<-1
    }
  }
}

for(i in 1: nrow(tempFinalDataTweetSquareBinaryMatrix)){
  for(j in 1: nrow(tempFinalDataTweetSquareBinaryMatrix)){
    if (tempFinalDataTweetSquareBinaryMatrix[j,i]==1) {
      tempFinalDataTweetSquareBinaryMatrix[j,which(tempFinalDataTweetSquareBinaryMatrix[i,]==1)]<-1
    }
  }
}

xtab <- table(tempFinalDataRefrencesSquareBinaryMatrix,FinalDataTweetSquareBinaryMatrix)

xtab <- table(tempFinalDataRefrencesSquareBinaryMatrix,tempFinalDataTweetSquareBinaryMatrix)
xtab <- table(FinalDataRefrencesSquareBinaryMatrix,FinalDataTweetSquareBinaryMatrix)
results <- confusionMatrix(xtab)
results


write.csv(FinalDataRefrencesSquareBinaryMatrix, file = "FinalDataRefrencesSquareBinaryMatrix.csv", row.names = FALSE)
write.csv(FinalDataTweetSquareBinaryMatrix, file = "FinalDataTweetSquareBinaryMatrix.csv", row.names = FALSE)
write.csv(tempFinalDataRefrencesSquareBinaryMatrix, file = "tempFinalDataRefrencesSquareBinaryMatrix.csv", row.names = FALSE)

###############################################

#Pick papers number of references greater than 20

sampleRefreencesMatrix<-FinalDataRefrencesMatrix[rowSums(FinalDataRefrencesMatrix)>20, colSums(FinalDataRefrencesMatrix)>1]
sampleRefreencesMatrix<- sampleRefreencesMatrix[rowSums(sampleRefreencesMatrix)>20,]
sampleRefreencesSquareMatrix <- sampleRefreencesMatrix %*% t(sampleRefreencesMatrix)
sum(sampleRefreencesSquareMatrix[row(sampleRefreencesSquareMatrix)==col(sampleRefreencesSquareMatrix)] > 20)

FinalSampleRefrencesMatrix <- sampleRefreencesSquareMatrix[intersect(rownames(sampleRefreencesSquareMatrix), rownames(FinalDataTweetSquareBinaryMatrix)),intersect(colnames(sampleRefreencesSquareMatrix), colnames(FinalDataTweetSquareBinaryMatrix))]
FinalSampleTweetMatrix     <- FinalDataTweetSquareMatrix[intersect(rownames(sampleRefreencesSquareMatrix), rownames(FinalDataTweetSquareMatrix)),intersect(colnames(sampleRefreencesSquareMatrix), colnames(FinalDataTweetSquareMatrix))]
sum(FinalSampleTweetMatrix[row(FinalSampleTweetMatrix)==col(FinalSampleTweetMatrix)] > 20)



finalSampleRefrencesBinaryMatrix <- FinalSampleRefrencesMatrix
finalSampleRefrencesBinaryMatrix[finalSampleRefrencesBinaryMatrix>1] <- 1

finalSampleTweetBinaryMatrix <- FinalSampleTweetMatrix
finalSampleTweetBinaryMatrix[finalSampleTweetBinaryMatrix>1] <- 1
  

xtab <- table(finalSampleRefrencesBinaryMatrix,finalSampleTweetBinaryMatrix)
results <- confusionMatrix(xtab)
results

#Pick papers number of references greater than 10
sampleRefreencesMatrix<-FinalDataRefrencesMatrix[rowSums(FinalDataRefrencesMatrix)>10, colSums(FinalDataRefrencesMatrix)>1]
sampleRefreencesMatrix<- sampleRefreencesMatrix[rowSums(sampleRefreencesMatrix)>10,]
sampleRefreencesSquareMatrix <- sampleRefreencesMatrix %*% t(sampleRefreencesMatrix)
sum(sampleRefreencesSquareMatrix[row(sampleRefreencesSquareMatrix)==col(sampleRefreencesSquareMatrix)] > 10)

FinalSampleRefrencesMatrix <- sampleRefreencesSquareMatrix[intersect(rownames(sampleRefreencesSquareMatrix), rownames(FinalDataTweetSquareBinaryMatrix)),intersect(colnames(sampleRefreencesSquareMatrix), colnames(FinalDataTweetSquareBinaryMatrix))]
FinalSampleTweetMatrix     <- FinalDataTweetSquareMatrix[intersect(rownames(sampleRefreencesSquareMatrix), rownames(FinalDataTweetSquareMatrix)),intersect(colnames(sampleRefreencesSquareMatrix), colnames(FinalDataTweetSquareMatrix))]
sum(FinalSampleTweetMatrix[row(FinalSampleTweetMatrix)==col(FinalSampleTweetMatrix)] > 10)



finalSampleRefrencesBinaryMatrix <- FinalSampleRefrencesMatrix
finalSampleRefrencesBinaryMatrix[finalSampleRefrencesBinaryMatrix>1] <- 1

finalSampleTweetBinaryMatrix <- FinalSampleTweetMatrix
finalSampleTweetBinaryMatrix[finalSampleTweetBinaryMatrix>1] <- 1


xtab <- table(finalSampleRefrencesBinaryMatrix,finalSampleTweetBinaryMatrix)
results <- confusionMatrix(xtab)
results

#Pick papers number of references greater than 5

sampleRefreencesMatrix<-FinalDataRefrencesMatrix[, colSums(FinalDataRefrencesMatrix)>5]
sampleRefreencesMatrix<-FinalDataRefrencesMatrix[rowSums(FinalDataRefrencesMatrix)>5, colSums(FinalDataRefrencesMatrix)>1]
sampleRefreencesMatrix<- sampleRefreencesMatrix[rowSums(sampleRefreencesMatrix)>5,]
sampleRefreencesSquareMatrix <- sampleRefreencesMatrix %*% t(sampleRefreencesMatrix)
sum(sampleRefreencesSquareMatrix[row(sampleRefreencesSquareMatrix)==col(sampleRefreencesSquareMatrix)] > 5)

FinalSampleRefrencesMatrix <- sampleRefreencesSquareMatrix[intersect(rownames(sampleRefreencesSquareMatrix), rownames(FinalDataTweetSquareBinaryMatrix)),intersect(colnames(sampleRefreencesSquareMatrix), colnames(FinalDataTweetSquareBinaryMatrix))]
FinalSampleTweetMatrix     <- FinalDataTweetSquareMatrix[intersect(rownames(FinalSampleRefrencesMatrix), rownames(FinalDataTweetSquareMatrix)),intersect(colnames(FinalSampleRefrencesMatrix), colnames(FinalDataTweetSquareMatrix))]
sum(FinalSampleTweetMatrix[row(FinalSampleTweetMatrix)==col(FinalSampleTweetMatrix)] > 5)



finalSampleRefrencesBinaryMatrix <- FinalSampleRefrencesMatrix
finalSampleRefrencesBinaryMatrix[finalSampleRefrencesBinaryMatrix>1] <- 1

finalSampleTweetBinaryMatrix <- FinalSampleTweetMatrix
finalSampleTweetBinaryMatrix[finalSampleTweetBinaryMatrix>1] <- 1


xtab <- table(finalSampleRefrencesBinaryMatrix,finalSampleTweetBinaryMatrix)
results <- confusionMatrix(xtab)
results
   
#Pick papers number of references greater than 5

sampleRefreencesMatrix<-FinalDataRefrencesMatrix[rowSums(FinalDataRefrencesMatrix)>4, colSums(FinalDataRefrencesMatrix)>1]
sampleRefreencesMatrix<- sampleRefreencesMatrix[rowSums(sampleRefreencesMatrix)>4,]
sampleRefreencesSquareMatrix <- sampleRefreencesMatrix %*% t(sampleRefreencesMatrix)
sum(sampleRefreencesSquareMatrix[row(sampleRefreencesSquareMatrix)==col(sampleRefreencesSquareMatrix)] > 4)

FinalSampleRefrencesMatrix <- sampleRefreencesSquareMatrix[intersect(rownames(sampleRefreencesSquareMatrix), rownames(FinalDataTweetSquareBinaryMatrix)),intersect(colnames(sampleRefreencesSquareMatrix), colnames(FinalDataTweetSquareBinaryMatrix))]
FinalSampleTweetMatrix     <- FinalDataTweetSquareMatrix[intersect(rownames(sampleRefreencesSquareMatrix), rownames(FinalDataTweetSquareMatrix)),intersect(colnames(sampleRefreencesSquareMatrix), colnames(FinalDataTweetSquareMatrix))]
sum(FinalSampleTweetMatrix[row(FinalSampleTweetMatrix)==col(FinalSampleTweetMatrix)] > 4)



finalSampleRefrencesBinaryMatrix <- FinalSampleRefrencesMatrix
finalSampleRefrencesBinaryMatrix[finalSampleRefrencesBinaryMatrix>1] <- 1

finalSampleTweetBinaryMatrix <- FinalSampleTweetMatrix
finalSampleTweetBinaryMatrix[finalSampleTweetBinaryMatrix>1] <- 1


xtab <- table(finalSampleRefrencesBinaryMatrix,finalSampleTweetBinaryMatrix)
results <- confusionMatrix(xtab)
results

#Pick papers number of references greater than 3

sampleRefreencesMatrix<-FinalDataRefrencesMatrix[rowSums(FinalDataRefrencesMatrix)>3, colSums(FinalDataRefrencesMatrix)>1]
sampleRefreencesMatrix<- sampleRefreencesMatrix[rowSums(sampleRefreencesMatrix)>3,]
sampleRefreencesSquareMatrix <- sampleRefreencesMatrix %*% t(sampleRefreencesMatrix)
sum(sampleRefreencesSquareMatrix[row(sampleRefreencesSquareMatrix)==col(sampleRefreencesSquareMatrix)] > 3)

FinalSampleRefrencesMatrix <- sampleRefreencesSquareMatrix[intersect(rownames(sampleRefreencesSquareMatrix), rownames(FinalDataTweetSquareBinaryMatrix)),intersect(colnames(sampleRefreencesSquareMatrix), colnames(FinalDataTweetSquareBinaryMatrix))]
FinalSampleTweetMatrix     <- FinalDataTweetSquareMatrix[intersect(rownames(sampleRefreencesSquareMatrix), rownames(FinalDataTweetSquareMatrix)),intersect(colnames(sampleRefreencesSquareMatrix), colnames(FinalDataTweetSquareMatrix))]
sum(FinalSampleTweetMatrix[row(FinalSampleTweetMatrix)==col(FinalSampleTweetMatrix)] > 3)



finalSampleRefrencesBinaryMatrix <- FinalSampleRefrencesMatrix
finalSampleRefrencesBinaryMatrix[finalSampleRefrencesBinaryMatrix>1] <- 1

finalSampleTweetBinaryMatrix <- FinalSampleTweetMatrix
finalSampleTweetBinaryMatrix[finalSampleTweetBinaryMatrix>1] <- 1


xtab <- table(finalSampleRefrencesBinaryMatrix,finalSampleTweetBinaryMatrix)
results <- confusionMatrix(xtab)
results


#Pick papers number of tweets greater than 20

#Create Matrix of Size Doi unique and unique Refrences
sampleTweetMatrix<-FinalDataTweetMatrix[, colSums(FinalDataTweetMatrix)>20]
sampleTweetMatrix<-FinalDataTweetMatrix[rowSums(FinalDataTweetMatrix)>20, colSums(FinalDataTweetMatrix)>1]
sampleTweetMatrix<- sampleTweetMatrix[rowSums(sampleTweetMatrix)>20,]
sampleTweetSquareMatrix <- sampleTweetMatrix %*% t(sampleTweetMatrix)
sum(sampleTweetSquareMatrix[row(sampleTweetSquareMatrix)==col(sampleTweetSquareMatrix)] > 20)


FinalSampleTweetMatrix     <- sampleTweetSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(sampleTweetSquareMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(sampleTweetSquareMatrix))]
sum(FinalSampleTweetMatrix[row(FinalSampleTweetMatrix) ==col(FinalSampleTweetMatrix)] > 20)


FinalSampleRefrencesMatrix <- FinalDataRefrencesSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(FinalSampleTweetMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(FinalSampleTweetMatrix))]
#sum(FinalSampleRefrencesMatrix[row(FinalSampleRefrencesMatrix) ==col(FinalSampleRefrencesMatrix)])


finalSampleRefrencesBinaryMatrix <- FinalSampleRefrencesMatrix
finalSampleRefrencesBinaryMatrix[finalSampleRefrencesBinaryMatrix>1] <- 1

write.csv(FinalSampleRefrencesMatrix, file = "VosViewerData/FinalSampleRefrencesMatrixGreaterThan20.csv", col.names = FALSE)
write.csv(FinalSampleTweetMatrix, file = "VosViewerData/FinalSampleTweetMatrixGreaterThan20.csv", col.names = FALSE)

finalSampleTweetBinaryMatrix <- FinalSampleTweetMatrix
finalSampleTweetBinaryMatrix[finalSampleTweetBinaryMatrix>1] <- 1


xtab <- table(finalSampleRefrencesBinaryMatrix,finalSampleTweetBinaryMatrix)
results <- confusionMatrix(xtab)
results


#Pick papers number of tweets greater than 10
sampleTweetMatrix<-FinalDataTweetMatrix[rowSums(FinalDataTweetMatrix)>10, colSums(FinalDataTweetMatrix)>1]
sampleTweetMatrix<- sampleTweetMatrix[rowSums(sampleTweetMatrix)>10,]
sampleTweetSquareMatrix <- sampleTweetMatrix %*% t(sampleTweetMatrix)
sum(sampleTweetSquareMatrix[row(sampleTweetSquareMatrix)==col(sampleTweetSquareMatrix)] > 10)


FinalSampleTweetMatrix     <- sampleTweetSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(sampleTweetSquareMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(sampleTweetSquareMatrix))]
sum(FinalSampleTweetMatrix[row(FinalSampleTweetMatrix) ==col(FinalSampleTweetMatrix)] > 10)


FinalSampleRefrencesMatrix <- FinalDataRefrencesSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(FinalSampleTweetMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(FinalSampleTweetMatrix))]
#sum(FinalSampleRefrencesMatrix[row(FinalSampleRefrencesMatrix) ==col(FinalSampleRefrencesMatrix)])


write.csv(FinalSampleRefrencesMatrix, file = "VosViewerData/FinalSampleRefrencesMatrixGreaterThan10.csv", col.names = FALSE)
write.csv(FinalSampleTweetMatrix, file = "VosViewerData/FinalSampleTweetMatrixGreaterThan10.csv", col.names = FALSE)

finalSampleRefrencesBinaryMatrix <- FinalSampleRefrencesMatrix
finalSampleRefrencesBinaryMatrix[finalSampleRefrencesBinaryMatrix>1] <- 1

finalSampleTweetBinaryMatrix <- FinalSampleTweetMatrix
finalSampleTweetBinaryMatrix[finalSampleTweetBinaryMatrix>1] <- 1


xtab <- table(finalSampleRefrencesBinaryMatrix,finalSampleTweetBinaryMatrix)
results <- confusionMatrix(xtab)
results

#Pick papers number of tweets greater than 5

sampleTweetMatrix<-FinalDataTweetMatrix[rowSums(FinalDataTweetMatrix)>5, colSums(FinalDataTweetMatrix)>1]
sampleTweetMatrix<- sampleTweetMatrix[rowSums(sampleTweetMatrix)>5,]
sampleTweetSquareMatrix <- sampleTweetMatrix %*% t(sampleTweetMatrix)
sum(sampleTweetSquareMatrix[row(sampleTweetSquareMatrix)==col(sampleTweetSquareMatrix)] > 5)


FinalSampleTweetMatrix     <- sampleTweetSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(sampleTweetSquareMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(sampleTweetSquareMatrix))]
sum(FinalSampleTweetMatrix[row(FinalSampleTweetMatrix) ==col(FinalSampleTweetMatrix)] > 5)


FinalSampleRefrencesMatrix <- FinalDataRefrencesSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(FinalSampleTweetMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(FinalSampleTweetMatrix))]
sum(FinalSampleRefrencesMatrix[row(FinalSampleRefrencesMatrix) ==col(FinalSampleRefrencesMatrix)])

write.csv(FinalSampleRefrencesMatrix, file = "VosViewerData/FinalSampleRefrencesMatrixGreaterThan5.csv", col.names = FALSE)
write.csv(FinalSampleTweetMatrix, file = "VosViewerData/FinalSampleTweetMatrixGreaterThan5.csv", col.names = FALSE)



finalSampleRefrencesBinaryMatrix <- FinalSampleRefrencesMatrix
finalSampleRefrencesBinaryMatrix[finalSampleRefrencesBinaryMatrix>1] <- 1

finalSampleTweetBinaryMatrix <- FinalSampleTweetMatrix
finalSampleTweetBinaryMatrix[finalSampleTweetBinaryMatrix>1] <- 1


xtab <- table(finalSampleRefrencesBinaryMatrix,finalSampleTweetBinaryMatrix)
results <- confusionMatrix(xtab)
results


#Pick papers number of tweets greater than 4

sampleTweetMatrix<-FinalDataTweetMatrix[rowSums(FinalDataTweetMatrix)>4, colSums(FinalDataTweetMatrix)>1]
sampleTweetMatrix<- sampleTweetMatrix[rowSums(sampleTweetMatrix)>4,]
sampleTweetSquareMatrix <- sampleTweetMatrix %*% t(sampleTweetMatrix)
sum(sampleTweetSquareMatrix[row(sampleTweetSquareMatrix)==col(sampleTweetSquareMatrix)] > 4)


FinalSampleTweetMatrix     <- sampleTweetSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(sampleTweetSquareMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(sampleTweetSquareMatrix))]
sum(FinalSampleTweetMatrix[row(FinalSampleTweetMatrix) ==col(FinalSampleTweetMatrix)] > 4)


FinalSampleRefrencesMatrix <- FinalDataRefrencesSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(FinalSampleTweetMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(FinalSampleTweetMatrix))]
sum(FinalSampleRefrencesMatrix[row(FinalSampleRefrencesMatrix) ==col(FinalSampleRefrencesMatrix)])

write.csv(FinalSampleRefrencesMatrix, file = "VosViewerData/FinalSampleRefrencesMatrixGreaterThan4.csv", col.names = FALSE)
write.csv(FinalSampleTweetMatrix, file = "VosViewerData/FinalSampleTweetMatrixGreaterThan4.csv", col.names = FALSE)


finalSampleRefrencesBinaryMatrix <- FinalSampleRefrencesMatrix
finalSampleRefrencesBinaryMatrix[finalSampleRefrencesBinaryMatrix>1] <- 1

finalSampleTweetBinaryMatrix <- FinalSampleTweetMatrix
finalSampleTweetBinaryMatrix[finalSampleTweetBinaryMatrix>1] <- 1

xtab <- table(finalSampleRefrencesBinaryMatrix,finalSampleTweetBinaryMatrix)
results <- confusionMatrix(xtab)
results

#Pick papers number of tweets greater than 3

sampleTweetMatrix<-FinalDataTweetMatrix[, colSums(FinalDataTweetMatrix)>3]
sampleTweetMatrix<- sampleTweetMatrix[rowSums(sampleTweetMatrix)>3,]
sampleTweetSquareMatrix <- sampleTweetMatrix %*% t(sampleTweetMatrix)
sum(sampleTweetSquareMatrix[row(sampleTweetSquareMatrix)==col(sampleTweetSquareMatrix)] > 3)

FinalSampleTweetMatrix     <- sampleTweetSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(sampleTweetSquareMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(sampleTweetSquareMatrix))]
sum(FinalSampleTweetMatrix[row(FinalSampleTweetMatrix) ==col(FinalSampleTweetMatrix)] > 3)
FinalSampleRefrencesMatrix <- FinalDataRefrencesSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(FinalSampleTweetMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(FinalSampleTweetMatrix))]
sum(FinalSampleRefrencesMatrix[row(FinalSampleRefrencesMatrix) == col(FinalSampleRefrencesMatrix)])


write.csv(FinalSampleRefrencesMatrix, file = "VosViewerData/FinalSampleRefrencesMatrixGreaterThan3.csv", col.names = FALSE)
write.csv(FinalSampleTweetMatrix, file = "VosViewerData/FinalSampleTweetMatrixGreaterThan3.csv", col.names = FALSE)


finalSampleRefrencesBinaryMatrix <- FinalSampleRefrencesMatrix
finalSampleRefrencesBinaryMatrix[finalSampleRefrencesBinaryMatrix>1] <- 1

finalSampleTweetBinaryMatrix <- FinalSampleTweetMatrix
finalSampleTweetBinaryMatrix[finalSampleTweetBinaryMatrix>1] <- 1



xtab <- table(finalSampleRefrencesBinaryMatrix,finalSampleTweetBinaryMatrix)
results <- confusionMatrix(xtab)
results 

#Pick papers number of tweets greater than 2

sampleTweetMatrix<-FinalDataTweetMatrix[rowSums(FinalDataTweetMatrix)>2, colSums(FinalDataTweetMatrix)>1]
sampleTweetMatrix<- sampleTweetMatrix[rowSums(sampleTweetMatrix)>2,]
sampleTweetSquareMatrix <- sampleTweetMatrix %*% t(sampleTweetMatrix)
sum(sampleTweetSquareMatrix[row(sampleTweetSquareMatrix)==col(sampleTweetSquareMatrix)] > 2)

FinalSampleTweetMatrix     <- sampleTweetSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(sampleTweetSquareMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(sampleTweetSquareMatrix))]
sum(FinalSampleTweetMatrix[row(FinalSampleTweetMatrix) ==col(FinalSampleTweetMatrix)] > 2)
FinalSampleRefrencesMatrix <- FinalDataRefrencesSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(FinalSampleTweetMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(FinalSampleTweetMatrix))]

write.csv(FinalSampleRefrencesMatrix, file = "VosViewerData/FinalSampleRefrencesMatrixGreaterThan2.csv", col.names = FALSE)
write.csv(FinalSampleTweetMatrix, file = "VosViewerData/FinalSampleTweetMatrixGreaterThan2.csv", col.names = FALSE)


finalSampleRefrencesBinaryMatrix <- FinalSampleRefrencesMatrix
finalSampleRefrencesBinaryMatrix[finalSampleRefrencesBinaryMatrix>1] <- 1

finalSampleTweetBinaryMatrix <- FinalSampleTweetMatrix
finalSampleTweetBinaryMatrix[finalSampleTweetBinaryMatrix>1] <- 1


xtab <- table(finalSampleRefrencesBinaryMatrix,finalSampleTweetBinaryMatrix)
results <- confusionMatrix(xtab)
results 



###########################
### Clustering by Journal

doiWithJournalsPublisher <- read.csv("doiWithJournalPublisher.csv",stringsAsFactors = FALSE)

JournalTweetSquareMatrix<-FinalDataTweetSquareMatrix
JournalRefrencesSquareMatrix<-FinalDataRefrencesSquareMatrix
JournalTweetSquareMatrix <- JournalTweetSquareMatrix[intersect(rownames(JournalRefrencesSquareMatrix), rownames(JournalTweetSquareMatrix)),intersect(colnames(JournalRefrencesSquareMatrix), colnames(JournalTweetSquareMatrix))]
JournalRefrencesSquareMatrix <- JournalRefrencesSquareMatrix[intersect(rownames(JournalRefrencesSquareMatrix), rownames(JournalTweetSquareMatrix)),intersect(colnames(JournalRefrencesSquareMatrix), colnames(JournalTweetSquareMatrix))]
JournalTweetSquareMatrix <-JournalTweetSquareMatrix[intersect(rownames(JournalTweetSquareMatrix),doiWithJournalsPublisher$citation.doi), intersect(rownames(JournalTweetSquareMatrix),doiWithJournalsPublisher$citation.doi)]
listOfIndex<-match(rownames(JournalTweetSquareMatrix),doiWithJournalsPublisher$citation.doi)

for(i in 1:nrow(JournalTweetSquareMatrix))
{
    rownames(JournalTweetSquareMatrix)[i] <- paste(doiWithJournalsPublisher$citation.journal[listOfIndex[i]],i)
    colnames(JournalTweetSquareMatrix)[i] <- paste(doiWithJournalsPublisher$citation.journal[listOfIndex[i]],i)
}

write.csv(JournalTweetSquareMatrix, file = "VosViewerData/JournalTweetSquareMatrix.csv", col.names = FALSE)


JournalRefrencesSquareMatrix <-JournalRefrencesSquareMatrix[intersect(rownames(JournalRefrencesSquareMatrix),doiWithJournalsPublisher$citation.doi), intersect(rownames(JournalRefrencesSquareMatrix),doiWithJournalsPublisher$citation.doi)]
listOfIndex<-match(rownames(JournalRefrencesSquareMatrix),doiWithJournalsPublisher$citation.doi)
for(i in 1:nrow(JournalRefrencesSquareMatrix))
{
  rownames(JournalRefrencesSquareMatrix)[i] <- paste(doiWithJournalsPublisher$citation.journal[listOfIndex[i]],i)
  colnames(JournalRefrencesSquareMatrix)[i] <- paste(doiWithJournalsPublisher$citation.journal[listOfIndex[i]],i)
}

write.csv(JournalRefrencesSquareMatrix, file = "VosViewerData/JournalRefrencesSquareMatrix.csv", col.names = FALSE)

####################################
####################################
#connceted component

graphRefrencesSquareBinaryMatrix <- graphRefrencesSquareBinaryMatrix[intersect(rownames(graphRefrencesSquareBinaryMatrix), rownames(graphTweetSquareBinaryMatrix)),intersect(colnames(graphRefrencesSquareBinaryMatrix), colnames(graphTweetSquareBinaryMatrix))]
graphTweetSquareBinaryMatrix     <- graphTweetSquareBinaryMatrix[intersect(rownames(graphRefrencesSquareBinaryMatrix), rownames(graphTweetSquareBinaryMatrix)),intersect(colnames(graphRefrencesSquareBinaryMatrix), colnames(graphTweetSquareBinaryMatrix))]

sampleTweetMatrix<-FinalDataTweetMatrix[rowSums(FinalDataTweetMatrix)>2, colSums(FinalDataTweetMatrix)>1]
sampleTweetMatrix<- sampleTweetMatrix[rowSums(sampleTweetMatrix)>2,]
sampleTweetMatrix <- sampleTweetMatrix[intersect(rownames(sampleTweetMatrix), rownames(graphTweetSquareBinaryMatrix)),]
sampleTweetSquareMatrix <- sampleTweetMatrix %*% t(sampleTweetMatrix)
sum(sampleTweetSquareMatrix[row(sampleTweetSquareMatrix)==col(sampleTweetSquareMatrix)] > 2)

FinalSampleTweetMatrix     <- sampleTweetSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(sampleTweetSquareMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(sampleTweetSquareMatrix))]
sum(FinalSampleTweetMatrix[row(FinalSampleTweetMatrix) == col(FinalSampleTweetMatrix)] > 2)
FinalSampleRefrencesMatrix <- FinalDataRefrencesSquareMatrix[intersect(rownames(FinalDataRefrencesSquareMatrix), rownames(FinalSampleTweetMatrix)),intersect(colnames(FinalDataRefrencesSquareMatrix), colnames(FinalSampleTweetMatrix))]

finalSampleRefrencesBinaryMatrix <- FinalSampleRefrencesMatrix
finalSampleRefrencesBinaryMatrix[finalSampleRefrencesBinaryMatrix>1] <- 1

finalSampleTweetBinaryMatrix <- FinalSampleTweetMatrix
finalSampleTweetBinaryMatrix[finalSampleTweetBinaryMatrix>1] <- 1


xtab <- table(finalSampleRefrencesBinaryMatrix,finalSampleTweetBinaryMatrix)
results <- confusionMatrix(xtab)
results 


###############################################

#Find Average Degree of Graph

mean(degree(FinalDataRefrencesSquareBinaryMatrix))
mean(degree(FinalDataTweetSquareBinaryMatrix))

###############################################

#Connected Component
components(FinalDataRefrencesSquareBinaryMatrix)
components(FinalDataTweetSquareBinaryMatrix)



